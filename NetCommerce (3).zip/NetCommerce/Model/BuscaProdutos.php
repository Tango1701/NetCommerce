<?php

    include_once("conexao.php");

    $string_select = "SELECT * From produtoaceite";

    $recebe = mysqli_query($conect, $string_select);

    while($linha[] = mysqli_fetch_assoc($recebe)){
        $item = $linha;
        $json = json_encode($item);
    }

    echo $json

?>