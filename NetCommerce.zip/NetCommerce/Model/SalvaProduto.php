

<?php
 
 // Importing DBConfig.php file.
 include_once("conexao.php");
  
  // Getting the received JSON into $json variable.
    $json = file_get_contents('php://input');
  
  // decoding the received JSON and store into $obj variable.
  $obj = json_decode($json, true);
  
 $Id_Produto = "p0007";
 $Id_Usuario = "u0002";
 $name = $obj['marca'] + $obj['modelo'];
 $tipo = $obj['tipo'];
 $preco = $obj['preco'];
 $descricao = $obj['descricao'];
 $tempo_uso = $obj['tempo_uso'];
 $detalhes =  $descricao +  $tempo_uso;
  
  // Creating SQL query and insert the record into MySQL database table.
 $Sql_Query = "INSERT INTO produto (Id_Produto, Id_Usuario, Nome, Tipo, Preco, Imagem, Video, Descricao) 
 VALUES ('$Id_Produto','$Id_Usuario', '$name','$tipo','$preco','teste', null,'$detalhes')";
  
  if(mysqli_query($conect, $Sql_Query)){
  
  // If the record inserted successfully then show the message.
 $MSG = 'Data Inserted Successfully into MySQL Database' ;
  
 // Converting the message into JSON format.
 $json = json_encode($MSG);
  
 // Echo the message.
  echo $json ;
  
  }
  else{
  
  echo 'Try Again';
  
  }
//   mysqli_close($con);
 ?>