<?php


class Sessao{

    

    function login(){
        include_once("conexao.php");
            
            $user = $_POST["userN"];
            $pass = $_POST["passW"];
    
            if(isset($user) && isset($pass))
            {
                $string_select = "SELECT * From funcionario Where Id_Funcionario = '$user' and Senha = '$pass'";
                $recebe = mysqli_query($conect, $string_select);

                $linha = mysqli_fetch_assoc($recebe);
                
                if($linha['Id_Funcionario'] == $user && $linha['Senha'] == $pass)
                {
                    session_start();
                    $_SESSION["Usuario"] = $user;
                    $_SESSION["Senha"] = $pass;
                    $_SESSION["Nome"] = $linha['Nome'];
                    setcookie('entrada','sucesso', time()+120);
                    header("location: /NetCommerce/index.php/home");
                } 
            }
            else
            {
                echo "<script> alert('Preencha os Campos!'); </script>";
            }
    }
    
    function logOff()
    {
        session_start();
        unset($_SESSION['Usuario']);
        unset($_SESSION['Senha']);
        session_destroy();
        header("location: /NetCommerce/index.php");
    }

}

?>