-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 07-Fev-2022 às 06:39
-- Versão do servidor: 10.1.19-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `netcommerce`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `Id_Funcionario` varchar(10) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Tipo` varchar(5) NOT NULL,
  `Senha` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`Id_Funcionario`, `Nome`, `Tipo`, `Senha`) VALUES
('f0001', 'Mateus Tango', 'admin', 1234);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `Id_Produto` varchar(20) NOT NULL,
  `Id_Usuario` varchar(10) NOT NULL,
  `Nome` varchar(100) NOT NULL,
  `Tipo` varchar(10) NOT NULL,
  `Preco` int(11) NOT NULL DEFAULT '0',
  `Imagem` varchar(100) NOT NULL,
  `Video` varchar(100) DEFAULT NULL,
  `Descricao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`Id_Produto`, `Id_Usuario`, `Nome`, `Tipo`, `Preco`, `Imagem`, `Video`, `Descricao`) VALUES
('p0002', 'u0001', 'Alcatel', 'Eletronico', 0, 'alcatel.jpg', NULL, 'Telefone Alcatel'),
('p0003', 'u0001', 'Nokia', 'Eletronico', 0, 'nokia.jpg', NULL, 'Telefone Nokia'),
('p0004', 'u0001', 'Samsung', 'Eletronico', 0, 'samsung.jpg', NULL, 'Telefone Samsung');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtoaceite`
--

CREATE TABLE `produtoaceite` (
  `Id_Produto` varchar(20) NOT NULL,
  `Id_Usuario` varchar(10) NOT NULL,
  `Nome` varchar(100) NOT NULL,
  `Tipo` varchar(50) NOT NULL,
  `Preco` int(11) NOT NULL,
  `Imagem` varchar(200) NOT NULL,
  `Video` varchar(200) DEFAULT NULL,
  `Descricao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produtoaceite`
--

INSERT INTO `produtoaceite` (`Id_Produto`, `Id_Usuario`, `Nome`, `Tipo`, `Preco`, `Imagem`, `Video`, `Descricao`) VALUES
('p0001', 'u0001', 'Huawei', 'Eletronico', 0, 'pink.jpg', NULL, 'Telefone Rosa'),
('p0005', 'u0002', 'Camisola - Zara', 'Roupa', 0, 'camiseta.jpg', NULL, 'Camisola zara. 2 meses de uso em bom estado');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`Id_Funcionario`);

--
-- Indexes for table `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`Id_Produto`);

--
-- Indexes for table `produtoaceite`
--
ALTER TABLE `produtoaceite`
  ADD PRIMARY KEY (`Id_Produto`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
