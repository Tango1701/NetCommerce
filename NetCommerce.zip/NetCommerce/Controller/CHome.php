<?php

require_once basepath."/NetCommerce/Model/Sessao.php";
require_once basepath."/NetCommerce/Model/Gestao.php";

    class CHome
    {
        function chamaHome()
        {
           header("location: /NetCommerce/View/home.php");
        }
        function chamaLogin()
        {
            require basepath.'/NetCommerce/View/login.php';
        }
        function AprovaProduto()
        {
            $control = new Gestao();
            $control->Aprovar();
            unset($control);
        }
        function Entrar()
        {
            $control = new Sessao();
            $control->login();
            unset($control);
        }
        function Sair()
        {
            $control = new Sessao();
            $control->logoff();
            unset($control);
        }
        
    }		

?>